using UnityEngine;

public class Rotator : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector2(0, 90) * Time.deltaTime); //Rotating animation for key pickup
    }
}
